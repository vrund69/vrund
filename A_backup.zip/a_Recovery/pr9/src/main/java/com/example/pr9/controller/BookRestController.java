package com.example.pr9.controller;

import com.example.pr9.entity.Book;

//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.net.URI;
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/books")
//public class BookRestController {
//
//    private final List<Book> bookList = new ArrayList<>();
//
//    private int nextId = 1;
//
//    // POST /api/books
//    @PostMapping
//    public ResponseEntity<Book> createBook(
//            @RequestBody Book book) {
//
//        book.setId(nextId++);
//
//        bookList.add(book);
//
//        URI location = URI.create("/api/books/" + book.getId());
//
//        return ResponseEntity
//                .created(location)
//                .body(book);
//    }
//
//    // GET /api/books
//    @GetMapping
//    public ResponseEntity<List<Book>> getAllBooks() {
//
//        return ResponseEntity.ok(bookList);
//    }
//
//    // GET /api/books/{id}
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(
//            @PathVariable int id) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//                return ResponseEntity.ok(book);
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//
//    // PUT /api/books/{id}
//    @PutMapping("/{id}")
//    public ResponseEntity<Book> updateBook(
//            @PathVariable int id,
//            @RequestBody Book updatedBook) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//
//                if (updatedBook.getTitle() != null) {
//                    book.setTitle(updatedBook.getTitle());
//                }
//
//                if (updatedBook.getAuthor() != null) {
//                    book.setAuthor(updatedBook.getAuthor());
//                }
//
//                book.setPrice(updatedBook.getPrice());
//
//                return ResponseEntity.ok(book);
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//
//    // DELETE /api/books/{id}
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBook(
//            @PathVariable int id) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//
//                bookList.remove(book);
//
//                return ResponseEntity.noContent().build();
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//}

//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/books")
//public class BookRestController {
//
//    private List<Book> bookList = new ArrayList<>();
//
//    // POST - Add Book
//    @PostMapping
//    public ResponseEntity<Book> addBook(@RequestBody Book book) {
//
//        bookList.add(book);
//
//        return ResponseEntity
//                .status(HttpStatus.CREATED)
//                .body(book);
//    }
//
//    // GET - Get All Books
//    @GetMapping
//    public ResponseEntity<List<Book>> getAllBooks() {
//
//        return ResponseEntity.ok(bookList);
//    }
//
//    // GET - Get Book By ID
//    @GetMapping("/{id}")
//    public ResponseEntity<Book> getBookById(@PathVariable int id) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//                return ResponseEntity.ok(book);
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//
//    // PUT - Update Book
//    @PutMapping("/{id}")
//    public ResponseEntity<Book> updateBook(
//            @PathVariable int id,
//            @RequestBody Book updatedBook) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//
//                book.setTitle(updatedBook.getTitle());
//                book.setAuthor(updatedBook.getAuthor());
//                book.setPrice(updatedBook.getPrice());
//
//                return ResponseEntity.ok(book);
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//
//    // DELETE - Delete Book
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
//
//        for (Book book : bookList) {
//
//            if (book.getId() == id) {
//
//                bookList.remove(book);
//
//                return ResponseEntity.noContent().build();
//            }
//        }
//
//        return ResponseEntity.notFound().build();
//    }
//}

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/books")
public class BookRestController {
	
	// Temporary storage for books in memory
    private List<Book> books = new ArrayList<>();
    
	@PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
		
		books.add(book);
		
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(book);
    }
	
	@GetMapping("/{id}")
	public ResponseEntity<Book> showBook(@PathVariable Integer id)
	{
		for (Book book : books) {

		    if (book.getId() == id) {
		        return ResponseEntity.ok(book);
		    }
		}

		return ResponseEntity.notFound().build();
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Book> updateBook(@RequestBody Book book,@PathVariable Integer id)
	{
		for(Book existingbook: books)
		{
			if(existingbook.getId()==id)
			{
				existingbook.setTitle(book.getTitle());
				existingbook.setPrice(book.getPrice());
	            return ResponseEntity.ok(existingbook);
			}
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable Integer id)
	{
		for(Book deleteBook:books)
		{
			if(deleteBook.getId()==id)
			{
				books.remove(deleteBook);
				return ResponseEntity.ok("Book deleted succesfully");
			}
		}
		return ResponseEntity.notFound().build();
	}
	
}